<!DOCTYPE html>
<html lang="en" xml:lang="en">
<head>


<link rel="preconnect" href="https://www.googletagmanager.com">
<link rel="preconnect" href="https://connect.facebook.net">
<link rel="preconnect" href="https://mx.technolutions.net">
<link rel="preconnect" href="https://kit-pro.fontawesome.com">
<link rel="preconnect" href="https://siteimproveanalytics.com">
<link rel="preconnect" href="https://stats.g.doubleclick.net">
<link rel="preconnect" href="https://www.google.com">
<link rel="preconnect" href="https://www.googleadservices.com">
<link rel="preconnect" href="https://googleads.g.doubleclick.net">
<link rel="preconnect" href="https://cx.atdmt.com">
<link rel="preconnect" href="https://www.facebook.com">
<link rel="preconnect" href="https://67771434.global.siteimproveanalytics.io">
<link rel="preconnect" href="https://bid.g.doubleclick.net">

<link rel="canonical" href="https://www.bradley.edu/home/404.dot" />



<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1" name="viewport">

<meta property="og:image" content="https://www.bradley.edu/global/images/facebook_defaultPreview_v2.png" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<meta property="og:image:type" content="image/png" />
<meta property="fb:app_id" content="257589315653" />
<meta property="og:type" content="website" />
<meta property="og:url" content="https://www.bradley.edu/home/404.dot" />


<meta name="google-site-verification" content="rWD1MzrQ0u1mC5aziUQRCBdmKGWqfr7RfkgH7LT0bvc" />



    
                               
                    
                            <title>Kaboom! | Bradley University</title>

<link rel="preload" href="/asset/fonts/glyphicons-halflings-regular.woff2" />

    <link rel="preload" href="/asset/css/bootstrap.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
        <noscript><link rel="stylesheet" href="/asset/css/bootstrap.min.css"></noscript> 
    <!--<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:500,800">-->
    <style type="text/css" media="screen">
        @font-face {
            font-family: 'Raleway',sans-serif;
            font-display: block;
            src: url(https://fonts.googleapis.com/css?family=Raleway:500,800);
            font-weight: 500;
        }
    </style>
    <link rel="preload" href="/asset/css/animate.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
        <noscript><link rel="stylesheet" href="/asset/css/animate.css"></noscript><!-- for additional animation functions -->
    <link rel="preload" href="/asset/css/mainStyles.min.css?v=20210209064400" as="style" onload="this.onload=null;this.rel='stylesheet'">
        <noscript><link rel="stylesheet" href="/asset/css/mainStyles.min.css?v=20210209064400"></noscript><!-- main university stylesheet -->
    <link rel="preload" href="/asset/css/nivo-slider.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
        <noscript><link rel="stylesheet" href="/asset/css/nivo-slider.css"></noscript><!-- for Nivo Slider -->
    <link rel="preload" href="/asset/css/theme-nivo.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
        <noscript><link rel="stylesheet" href="/asset/css/theme-nivo.css"></noscript><!-- for Nivo Slider -->

    <link rel="icon" href="/home/favicon.ico" type="image/x-icon">

    <script defer src="/asset/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="/asset/js/jquery.min.js" type="text/javascript"></script>
    <script defer src="https://kit.fontawesome.com/56822513b0.js" crossorigin="anonymous" integrity="sha384-OdlNKjSohokL5z1jQue71XrlXrqoIO6V6VHiON+qZPPCBH2/R7wVTPEQAwafp18n"></script>
    <script defer src="/asset/js/jquery.matchHeight-min.js" type="text/javascript"></script><!-- squares/columns to match heights -->
    <script defer src="/asset/js/countUp.js" type="text/javascript"></script><!-- count up -->
    <script defer src="/asset/js/jquery.waypoints.min.js" type="text/javascript"></script><!-- do stuff when hits certain points -->
    <script defer src="/asset/js/jquery.nivo.slider.pack.js" type="text/javascript"></script>
    <script defer src="/asset/js/hoverDropdown.js" type="text/javascript"></script><!-- navbar animations & other stuff -->
    <script defer src="/asset/js/jPushMenu.js" type="text/javascript"></script><!-- mobile nav push in -->
    <!--<script src="/asset/js/v2p.js" type="text/javascript"></script>--><!-- old mobile nav push in -->
    
    <!-- STICKY NAV JS -->
    <script type="text/javascript">
    (function($) {
    $(document).ready(function() {
      $(window).scroll(function() {
        if ($(this).scrollTop() > 120) {
          $('.stickyNav').fadeIn(250);
        } else {
          $('.stickyNav').fadeOut(250);
        }
      });
    });
    })(jQuery);
    </script>
    
    <!-- MATCH HEIGHT -->
    <script type="text/javascript">
    (function($) {
        $(document).ready(function() {
            $('.bWhite-square-matchHeight').matchHeight();
        });
    })(jQuery);
    (function($) {
        $(document).ready(function() {
            $('.transparent-black-square-matchHeight').matchHeight();
        });
    })(jQuery);
    (function($) {
        $(document).ready(function() {
            $('.matchHeight').matchHeight();
        });
    })(jQuery);
    </script>

    <!-- HAMBURGER OPEN/CLOSE -->
    <script type="text/javascript">
    (function($) {
    $(document).ready(function () {
      var trigger = $('.hamburger'),
          overlay = $('.overlay'),
         isClosed = false;

        trigger.click(function () {
          hamburger_cross();      
        });

        function hamburger_cross() {

          if (isClosed == true) {          
            overlay.hide();
            trigger.removeClass('is-open');
            trigger.addClass('is-closed');
            isClosed = false;
          } else {   
            overlay.show();
            trigger.removeClass('is-closed');
            trigger.addClass('is-open');
            isClosed = true;
          }
      }
    });
    })(jQuery);
    </script>

    <!-- MOBILE MENU PUSH PAGE -->
    <script type="text/javascript">
      //<![CDATA[
      $(document).ready(function(){
        $('.toggle-menu').jPushMenu({closeOnClickLink: false});
        $('.dropdown-toggle').dropdown();
      });
      //]]>
    </script>
    
    <!-- NIVO SLIDER -->
    <script type="text/javascript"> 
    $(window).load(function() {
        $('#slider').nivoSlider({ 
            effect: 'slideInLeft',            // Specify sets like: 'fold,fade,sliceDown' 
            animSpeed: 500,                   // Slide transition speed 
            pauseTime: 3000,                  // How long each slide will show 
            startSlide: 0,                    // Set starting Slide (0 index) 
            directionNav: true,               // Next & Prev navigation 
            controlNav: false,                // 1,2,3... navigation 
            controlNavThumbs: false,          // Use thumbnails for Control Nav 
            pauseOnHover: true,               // Stop animation while hovering
            manualAdvance: true, 
        });
    }); 
    </script>
    
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-6234493-1']);
  _gaq.push(['_setDomainName', '.bradley.edu']);
  _gaq.push(['_trackPageview']);
  _gaq.push(['_trackPageLoadTime']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-K2NX5B3');</script>
<!-- End Google Tag Manager -->

<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','//connect.facebook.net/en_US/fbevents.js');

fbq('init', '1666421876940157');
fbq('track', "PageView");</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=1666421876940157&ev=PageView&noscript=1" alt=""/></noscript>
<!-- End Facebook Pixel Code -->

<!-- Snap Pixel Code -->
<script type='text/javascript'>
(function(e,t,n){if(e.snaptr)return;var a=e.snaptr=function()
{a.handleRequest?a.handleRequest.apply(a,arguments):a.queue.push(arguments)};
a.queue=[];var s='script';r=t.createElement(s);r.async=!0;
r.src=n;var u=t.getElementsByTagName(s)[0];
u.parentNode.insertBefore(r,u);})(window,document,
'https://sc-static.net/scevent.min.js');

snaptr('init', '41100890-64b1-49f8-a868-277662751128', {
'user_email': '__INSERT_USER_EMAIL__'
});

snaptr('track', 'PAGE_VIEW');

</script>
<!-- End Snap Pixel Code -->

<script type="text/javascript">
/*<![CDATA[*/
(function() {
var sz = document.createElement('script'); sz.type = 'text/javascript'; sz.async = true;
sz.src = '//siteimproveanalytics.com/js/siteanalyze_67771434.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(sz, s);
})();
/*]]>*/
</script>

<!--Begin Slate Ping Script-->
<script async="async" src="https://apply.bradley.edu/ping">/**/</script>
<!--End Slate Ping Script-->


<script type="text/javascript" src="//cdn.rlets.com/capture_configs/74d/276/52a/0c54b239c141b2f5d8f289d.js" async="async"></script>


<!-- Clarity First Party Script -->
<script src="https://n527.bradley.edu/script.js" ></script>
<!-- End Clarity First Party Script -->


<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-V7221XPXLQ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-V7221XPXLQ');
</script>
</head>

<body id="no-image">

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K2NX5B3"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->


<style>
@media screen and (max-width: 991px) {
    .emergency-alert {
        margin-top: 50px;
    }
}

@media screen and (min-width: 768px) {
    .covid-alert .row {
        display: flex;
        align-items: center;
    }
}
</style>

<style>
@media screen and (max-width: 991px) {
    .emergency-alert {
        margin-top: 50px;
    }
}
</style>



<!--
    <div class="row-color-bWhite emergency-alert">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-3">
                    <p style="font-size:30px; font-weight:bold; color:#a50000;">Emergency Alert</p>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-9" style="font-size:13px;">
                    <p style="margin-bottom:-5px; font-size:18px; font-weight:bold;">foreWarn: BU foreWarn</p>
                    The BU campus will be closed on 2/12/25. Classes will be remote. Offices should move to remote work.
                </div>
            </div>
        </div>
    </div>
-->


<!--
<div class="row-color-bWhite emergency-alert">
    <div class="container">
        <div class="row row-padding-top-20 row-padding-bottom-20">
            <div class="col-md-1 text-bRed hidden-xs hidden-sm">
                <i class="fas fa-user-graduate fa-4x"></i>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-11">
                <p style="font-size: 18px; margin-bottom: 4px !important;"><span class="text-bRed" style="font-size:25px; font-weight:bold;">Watch Live:</span><br>Congratulations to the Class of 2024! &nbsp;&nbsp;&nbsp;<a href="/sites/commencement/streaming/">Watch Now &nbsp;<i class="fas fa-video"></i></a></p>
            </div>
        </div>
    </div>
</div>
-->



<!--
<div class="row-color-bWhite emergency-alert covid-alert">
    <div class="container">
        <div class="row row-padding-top-10" style="padding-bottom: 6px;">
            <div class="col-xs-12 col-sm-10">
                <p style="font-size: 16px; margin-bottom: 4px !important;"><span class="text-uppercase" style="font-weight:bold; color:#a50000;">Coronavirus Information:</span><br>Bradley University revised <a href="https://www.bradley.edu/sites/coronavirus/important-news/story.dot?id=ec2f1456-c5ee-413b-854f-313907f5f004">its mask mandate</a> and physical distancing guidelines for fully vaccinated people, except in classes and on-campus residences.</p>
            </div>
            <div class="col-sm-2 col-md-1 hidden-xs visible-sm visible-md visible-lg">
                <a href="/sites/coronavirus/"><img src="/sites/coronavirus/assets/img/Logo-BradleyUnite-blackText.svg" class="img-responsive" alt="Bradley Unite Logo"></a>
            </div>
        </div>
    </div>
</div>
-->





    
            
    




<!--


-->

    <a href="#main-content" class="skip">Skip to main content</a>
<style>
.covid-alert img {
    width: 3.5em;
    transition: width 1s;
}

.covid-alert img:hover {
    width: 3.8em;
}

.covid-alert a:hover {
    font-size: 17px;
    text-decoration:none;
}
</style>

    <img src="/asset/img/Blogo_rgb_Hor-Print.png" class="center-block print-only-logo" alt="">
    <!-- MAIN MENU/MOBILE MENU -->
    <header>
        <div class="header-top header-primary hidden-xs hidden-sm">
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-6 col-md-offset-6">
                        <nav class="navbar">
                            <ul class="nav navbar-nav pull-right text-uppercase">
                                <li class="nav-apply"><a href="/apply/"><i class="fas fa-file-alt" aria-hidden="true"></i> Apply</a></li>
                                <li class="nav-visit"><a href="/admissions/freshman/visit/"><i class="fas fa-car" aria-hidden="true"></i> Visit</a></li>
                                <li class="nav-give"><a href="/giving/"><i class="fas fa-gift" aria-hidden="true"></i> Give</a></li>
                                <li class="top-audience"><a href="#" title="Audience"><span class="sr-only">Audience</span> <i class="fas fa-lg fa-users" aria-hidden="true"></i></a></li>
                                <li class="top-tools"><a href="#" title="Tools"><span class="sr-only">Tools</span> <i class="fas fa-lg fa-th" aria-hidden="true"></i></a></li>
                                <li class="top-search"><a href="#" title="Search"><span class="sr-only">Search</span> <i class="fas fa-lg fa-search" aria-hidden="true"></i></a></li>
                            </ul>
                        </nav>
                    </div><!-- .col-md-7 -->
                </div><!-- .row -->
            </div><!-- .container -->
            <div class="top-tools-container">
                <div class="container">
                    <div class="row">
                        <nav>
                            <ul class="nav nav-justified">
                                <li><a href="/atoz/"><i class="fas fa-list" aria-hidden="true"></i> A-Z Index</a></li>
                                <li><a href="/directory/"><i class="fas fa-phone" aria-hidden="true"></i> Directory</a></li>
                                <li><a href="/about/visiting/virtual_tour/"><i class="fas fa-map" aria-hidden="true"></i> Campus Map</a></li>
                                <li><a href="https://mail.bradley.edu/"><i class="far fa-envelope" aria-hidden="true"></i> BMail</a></li>
                                <li><a href="https://fsmail.bradley.edu/"><i class="fas fa-envelope" aria-hidden="true"></i> FSMail</a></li>
                                <li><a href="https://mybu.bradley.edu/"><i class="fas fa-desktop" aria-hidden="true"></i> MyBU</a></li>
                                <li><a href="https://learn.bradley.edu/"><i class="fas fa-chalkboard-teacher"></i> Canvas</a></li>
                                <!--<li><a href="https://sakaiarchive.bradley.edu/portal"><i class="far fa-clipboard" aria-hidden="true"></i> Sakai Archive</a></li>-->
                                <li><a href="https://sentry.bradley.edu/"><i class="fas fa-user-plus" aria-hidden="true"></i> Sentry</a></li>
                                <li><a href="https://mybradley.bradley.edu/"><i class="fas fa-laptop" aria-hidden="true"></i> MyBradley</a></li>
                            </ul>
                        </nav>
                    </div><!-- .row -->
                </div><!-- .container -->
            </div><!-- .top-tools-container -->
            <div class="top-search-container">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-md-6 col-md-offset-6 col-lg-offset-0">
                            <form method="get" action="/sitesearch/" id="siteSearch">
                                <label class="sr-only" for="search-site">
                                    Welcome to Bradley, how can we help you?
                                </label>
                                <div class="input-group">
                                    <input id="search-site" type="text" class="form-control" autocomplete="off" placeholder="welcome to Bradley, how can we help you?" name="q" />
                                    <span class="input-group-btn">
                                        <button class="btn btn-light" type="submit">Go</button>
                                    </span>
                                </div> <!-- .input-group -->
                            </form>
                        </div><!-- .col-md-4 -->
                        <div class="col-md-8">
                            <ul class="list-inline">
                                <li><h5 class="text-uppercase">Common Searches:</h5></li>
                                <li><a href="/offices/student/sfs/charges-payment/tuition-fees/"><i class="fas fa-graduation-cap" aria-hidden="true"></i> Tuition</a></li>
                                <li><a href="/calendar/"><i class="fas fa-calendar-alt" aria-hidden="true"></i> Calendar</a></li>
                                <li><a href="/offices/other/sfs/"><i class="far fa-money-bill-alt" aria-hidden="true"></i> Financial Aid</a></li>
                                <li><a href="/academic/classes/"><i class="far fa-list-alt" aria-hidden="true"></i> Schedule of Classes</a></li>
                                <li><a href="http://bradley.bncollege.com/"><i class="fas fa-book" aria-hidden="true"></i> Bookstore</a></li>
                            </ul>
                        </div><!-- .col-md-8 -->
                    </div><!-- .row -->
                </div><!-- .container -->
            </div><!-- .top-search-container -->
            <div class="top-audience-container">
                <div class="container">
                    <div class="row">
                        <nav>
                            <ul class="nav nav-justified">
                                <li><a href="/admissions/"><i class="fas fa-child" aria-hidden="true"></i> Future Students</a></li>
                                <li><a href="/currentstudents/"><i class="fas fa-users-class" aria-hidden="true"></i> Current Students</a></li>
                                <li><a href="/parent/"><i class="fas fa-user-friends" aria-hidden="true"></i> Parents</a></li>
                                <li><a href="/facultyorstaff/"><i class="fas fa-university" aria-hidden="true"></i> Faculty/Staff</a></li>
                                <li><a href="/alumni/"><i class="fas fa-user-graduate" aria-hidden="true"></i> Alumni</a></li>
                            </ul>
                        </nav>
                    </div><!-- .row -->
                </div><!-- .container -->
            </div><!-- .top-audience-container -->
        </div><!-- .header-top .header-primary -->
            
        <nav class="header-main header-transparent navbar navbar-fixed-top" role="navigation" id="slide-nav">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <a class="navbar-toggle toggle-menu menu-right push-body visible-xs visible-sm hamburger is-closed" data-toggle="collapse" data-target="#slidemenu">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="hamb-top"></span>
                    <span class="hamb-middle"></span>
                    <span class="hamb-bottom"></span>
                </a>
                <a class="navbar-brand main-logo" href="/" rel="home" title="Bradley University"><span class="sr-only">Bradley University</span> <img alt="Bradley University Logo" class="img-responsive" src="/asset/img/logo_v2.svg"></a>
                <a class="navbar-brand visible-xs visible-sm bradley-logo-link" href="/"><span class="sr-only">Bradley University</span><img alt="Bradley University Logo" class="bradley-logo" src="/asset/img/Bshield_rgb.svg"></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse cbp-spmenu cbp-spmenu-vertical cbp-spmenu-right" id="slidemenu">
                <ul class="nav navbar-nav text-uppercase">
                    <li class="visible-sm visible-xs">
                        <div class="mobile-nav-logo">
                            <a href="/"><span class="sr-only">Bradley University</span><img alt="Bradley University Logo" class="bradley-logo" src="/asset/img/Bshield_rgb.svg"></a>
                        </div>
                        <a aria-expanded="false" aria-haspopup="true" class="dropdown-toggle text-center mobile-quicklinks-icon" data-toggle="dropdown" href="#" role="button"><span class="sr-only">Tools</span> <i class="fas fa-th fa-lg tools-btn"></i></a>
                        <ul class="dropdown-menu">
                            <li><a href="/atoz/"><i class="fas fa-list" aria-hidden="true"></i> A-Z Index</a></li>
                            <li><a href="/directory/"><i class="fas fa-phone" aria-hidden="true"></i> Directory</a></li>
                            <li><a href="/about/visiting/virtual_tour/"><i class="fas fa-map" aria-hidden="true"></i> Campus Map</a></li>
                            <li><a href="https://mail.bradley.edu/"><i class="far fa-envelope" aria-hidden="true"></i> BMail</a></li>
                            <li><a href="https://fsmail.bradley.edu/"><i class="fas fa-envelope" aria-hidden="true"></i> FSMail</a></li>
                            <li><a href="https://mybu.bradley.edu/"><i class="fas fa-desktop" aria-hidden="true"></i> MyBU</a></li>
                            <li><a href="https://learn.bradley.edu/"><i class="fas fa-chalkboard-teacher"></i> Canvas</a></li>
                            <!--<li><a href="https://sakaiarchive.bradley.edu/portal"><i class="far fa-clipboard" aria-hidden="true"></i> Sakai Archive</a></li>-->
                            <li><a href="https://sentry.bradley.edu/"><i class="fas fa-user-plus" aria-hidden="true"></i> Sentry</a></li>
                            <li><a href="https://mybradley.bradley.edu/"><i class="fas fa-laptop" aria-hidden="true"></i> MyBradley</a></li>
                        </ul>
                    </li>
                    <div class="clearfix"></div>
                    <li class="visible-sm visible-xs">
                        <div class="mobile-search">
                            <form method="get" action="/sitesearch/" id="siteSearch">
                                <label class="sr-only" for="search-site-2">Search Bradley.edu</label>
                                <div class="input-group">
                                    <input id="search-site-2" type="text" class="form-control" autocomplete="off" placeholder="search Bradley.edu" name="q" />
                                    <span class="input-group-btn">
                                        <button class="btn btn-bRed" type="submit"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
                                    </span>
                                </div>
                            </form>
                        </div>
                    </li>
                    <li><a href="/about/">About</a></li>
                    <li><a href="/admissions/">Admission</a></li>
                    <li><a href="/academic/">Academics</a></li>
                    <li><a href="/campuslife/">Campus Life</a></li>
                    <li><a href="/alumni/">Alumni</a></li>
                    <li><a href="http://www.bradleybraves.com/">Athletics</a></li>
                    <li class="visible-xs visible-sm dropdown">
                        <a aria-expanded="false" aria-haspopup="true" class="dropdown-toggle" data-toggle="dropdown" href="#" role="button">Information for <b class="caret"></b></a>
                        <ul class="dropdown-menu nav-info-for">
                            <li><a href="/admissions/"><i class="fas fa-child" aria-hidden="true"></i> Future Students</a></li>
                            <li><a href="/currentstudents/"><i class="fas fa-users-class" aria-hidden="true"></i> Current Students</a></li>
                            <li><a href="/parent/"><i class="fas fa-user-friends" aria-hidden="true"></i> Parents</a></li>
                            <li><a href="/facultyorstaff/"><i class="fas fa-university" aria-hidden="true"></i> Faculty/Staff</a></li>
                            <li><a href="/alumni/"><i class="fas fa-user-graduate" aria-hidden="true"></i> Alumni</a></li>
                        </ul>
                    </li>
                    <li class="visible-xs visible-sm">
                        <ul class="nav nav-mobile-action-items">
                            <li class="col-xs-12">
                                <a class="btn btn-bRed" href="/apply/"><i class="far fa-file-alt" aria-hidden="true"></i> Apply</a>
                            </li>
                            <li class="col-xs-12">
                                <a class="btn btn-bRed" href="/admissions/freshman/visit/"><i class="fas fa-car" aria-hidden="true"></i> Visit</a>
                            </li>
                            <li class="col-xs-12">
                                <a class="btn btn-bRed" href="/giving/"><i class="fas fa-gift" aria-hidden="true"></i> Give</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
    </header>
    <!-- end MAIN MENU/MOBILE MENU -->
    
    <!-- STICKY NAVIGATION -->
    <div class="stickyNav">
        <div class="container-fluid row-color-bRed row-padding-sm">
            <div class="container">
                <div class="row">
                    <div class="col-md-1 shieldLogo">
                        <a class="bradley-logo-link" href="/"><img class="bradley-logo" alt="Bradley University Shield Logo" src="/asset/img/Bshield_rgb.svg"></a>
                    </div>
                    <div class="col-md-9 stickyNavLinks">
                        <ul class="list-inline text-uppercase">
                            <li><a href="/about/">About</a></li>
                            <li><a href="/admissions/">Admission</a></li>
                            <li><a href="/academic/">Academics</a></li>
                            <li><a href="/campuslife/">Campus Life</a></li>
                            <li><a href="/alumni/">Alumni</a></li>
                            <li><a href="http://www.bradleybraves.com/">Athletics</a></li>
                        </ul>
                    </div> <!-- col-md-9 stickyNavLinks -->
                    <div class="col-md-2">
                        <ul class="list-inline icon-only text-right">
                            <li class="sticky-audience"><a href="#" title="Audience"><span class="sr-only">Audience</span> <i class="fas fa-lg fa-users" aria-hidden="true"></i></a></li>
                            <li class="sticky-tools"><a href="#" title="Tools"><span class="sr-only">Tools</span> <i class="fas fa-lg fa-th" aria-hidden="true"></i></a></li>
                            <li class="sticky-search"><a href="#" title="Search"><span class="sr-only">Search</span> <i class="fas fa-lg fa-search" aria-hidden="true"></i></a></li>
                        </ul>
                    </div><!--col-md-2-->
                </div><!-- row -->
            </div><!-- container -->
        </div><!-- container-fluid row-color-bRed row-padding-sm -->
        <div class="sticky-tools-container">
            <div class="container">
                <div class="row">
                    <nav>
                        <ul class="nav nav-justified">
                            <li><a href="/atoz/"><i class="fas fa-list" aria-hidden="true"></i> A-Z Index</a></li>
                            <li><a href="/directory/"><i class="fas fa-phone" aria-hidden="true"></i> Directory</a></li>
                            <li><a href="/about/visiting/virtual_tour/"><i class="fas fa-map" aria-hidden="true"></i> Campus Map</a></li>
                            <li><a href="https://mail.bradley.edu/"><i class="far fa-envelope" aria-hidden="true"></i> BMail</a></li>
                            <li><a href="https://fsmail.bradley.edu/"><i class="fas fa-envelope" aria-hidden="true"></i> FSMail</a></li>
                            <li><a href="https://mybu.bradley.edu/"><i class="fas fa-desktop" aria-hidden="true"></i> MyBU</a></li>
                            <li><a href="https://learn.bradley.edu/"><i class="fas fa-chalkboard-teacher"></i> Canvas</a></li>
                            <!--<li><a href="https://sakaiarchive.bradley.edu/portal"><i class="far fa-clipboard" aria-hidden="true"></i> Sakai Archive</a></li>-->
                            <li><a href="https://sentry.bradley.edu/"><i class="fas fa-user-plus" aria-hidden="true"></i> Sentry</a></li>
                            <li><a href="https://mybradley.bradley.edu/"><i class="fas fa-laptop" aria-hidden="true"></i> MyBradley</a></li>
                        </ul>
                    </nav>
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .sticky-tools-container -->
        <div class="sticky-search-container">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-md-offset-6 col-lg-offset-0">
                        <form method="get" action="/sitesearch/" id="siteSearch">
                            <label class="sr-only" for="search-site-sticky">welcome to Bradley, how can we help you?</label>
                              <div class="input-group">
                                <input id="search-site-sticky" type="text" class="form-control" autocomplete="off" placeholder="welcome to Bradley, how can we help you?" name="q" />
                                <span class="input-group-btn"><button class="btn btn-light" type="submit">Go</button></span>
                              </div> <!-- .input-group -->
                        </form>
                    </div> <!-- .col-md-4 -->
                    <div class="col-md-8">
                        <ul class="list-inline">
                            <li><h5 class="text-uppercase">Common Searches:</h5></li>
                            <li><a href="/offices/student/sfs/charges-payment/tuition-fees/"><i class="fas fa-graduation-cap" aria-hidden="true"></i> Tuition</a></li>
                            <li><a href="/calendar/"><i class="fas fa-calendar-alt" aria-hidden="true"></i> Calendar</a></li>
                            <li><a href="/offices/other/sfs/"><i class="far fa-money-bill-alt" aria-hidden="true"></i> Financial Aid</a></li>
                            <li><a href="/academic/classes/"><i class="far fa-list-alt" aria-hidden="true"></i> Schedule of Classes</a></li>
                            <li><a href="http://bradley.bncollege.com/"><i class="fas fa-book" aria-hidden="true"></i> Bookstore</a></li>
                        </ul>
                    </div> <!-- .col-md-8 -->
                </div> <!-- .row -->
            </div> <!-- .container -->
        </div> <!-- .sticky-search-container -->
        <div class="sticky-audience-container">
            <div class="container">
                <div class="row">
                    <nav>
                        <ul class="nav nav-justified">
                            <li><a href="/admissions/"><i class="fas fa-child" aria-hidden="true"></i> Future Students</a></li>
                            <li><a href="/currentstudents/"><i class="fas fa-users-class" aria-hidden="true"></i> Current Students</a></li>
                            <li><a href="/parent/"><i class="fas fa-user-friends" aria-hidden="true"></i> Parents</a></li>
                            <li><a href="/facultyorstaff/"><i class="fas fa-university" aria-hidden="true"></i> Faculty/Staff</a></li>
                            <li><a href="/alumni/"><i class="fas fa-user-graduate" aria-hidden="true"></i> Alumni</a></li>
                        </ul>
                    </nav>
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .sticky-audience-container -->
    </div><!-- stickyNav -->
    <!-- end STICKY NAVIGATION -->
<div id="main-content"></div>
    
    <!-- BASIC PAGE SECTION -->
    <div class="row-color-bWhite row-padding-75">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    

                    <h1 class="text-uppercase">Kaboom!</h1>
<style>
.col-md-12 h1 {
    display: none;
}
.col-md-12 .col-sm-7 h1 {
    display: block;
}
@media only screen and (min-device-width: 767px) {
.col-sm-7 {
    padding-top: 12%;
}
}
@media only screen and (max-device-width: 767px) {
.col-sm-5 {
    padding-top:30px;
}
}
</style>

<div class="row">
    <div class="col-sm-7">
    <h1 class="text-uppercase">Kaboom!</h1>
    <p>Hmmm...the page or file you are trying to view is not available. To help find what you are looking for on Bradley University's website please use the <a href="/atoz/">A to Z Index</a> feature or search our site.</p>
    <h2>Site Search</h2>
    <form method="get" action="/sitesearch/" id="siteSearch">
        <label class="sr-only" for="search-site">
        Enter your search term here
        </label>
            <div class="input-group">
                <input id="search-site" type="text" class="form-control" autocomplete="off" placeholder="Enter your search term here" name="q" />
                <span class="input-group-btn">
                    <button class="btn btn-light" type="submit">Search</button>
                </span>
            </div> <!-- .input-group -->
    </form>
    </div>
    
    <div class="col-sm-5">
        <img src="/asset/img/Kaboom_404.png" alt="Kaboom!" class="img-responsive">
    </div>
</div>                    
                </div>
            </div>
        </div>
    </div><!--row-->
    <!--end BASIC PAGE SECTION-->

<style>
    .row-color-charcoal .btn-secondary-outline {
  color: #fff !important;
  background-color: #a50000;
  border-color: #700000;
}
.row-color-charcoal .btn-secondary-outline:hover {
  color: #a50000 !important;
  background-color: #f0f0f0;
  background-image: none;
  border-color: #700000;
}
</style>

<!-- FOOTER -->
<footer class="footer">
    <div class="social-media row-color-charcoal row-padding-lrg-noH1 text-center">
        <div class="container">
            <div class="col-md-7 col-md-offset-3">
                <ul class="footer-bttns list-inline text-uppercase">
                    <li><a href="/apply/"><div><i class="fas fa-file-alt fa-2x" aria-hidden="true"></i> <span class="hide-mobile">Apply</span></div></a></li>
                    <li><a href="/admissions/freshman/visit/"><div><i class="fas fa-car fa-2x" aria-hidden="true"></i> <span class="hide-mobile">Visit</span></div></a></li>
                    <li><a href="/giving/"><div><i class="fas fa-gift fa-2x" aria-hidden="true"></i> <span class="hide-mobile">Give</span></div></a></li>
                </ul>
            </div>
        </div><!--container-->
    </div><!--end social media row-->
    <div class="row-color-charcoal row-padding-footer">
        <div class="container hidden-xs hidden-sm hidden-md">
            <div class="col-md-2">
                <h5 class="text-uppercase">Information For</h5>
                <ul class="list-unstyled">
                    <li><a href="/admissions/">Prospective Students</a></li>
                    <li><a href="/currentstudents/">Current Students</a></li>
                    <li><a href="/facultyorstaff/">Faculty/Staff</a></li>
                    <li><a href="/family/">Parents</a></li>
                    <li><a href="/alumni/">Alumni</a></li>
                </ul>
            </div><!--end footer 1st col-->
            <div class="col-md-2">
                <h5 class="text-uppercase">Getting Around</h5>
                <ul class="list-unstyled">
                    <li><a href="/atoz/">A - Z index</a></li>
                    <li><a href="/about/visiting/virtual_tour/">Campus Map</a></li>
                    <li><a href="/parking/">Parking</a></li>
                    <li><a href="/about/visiting/">Visit Information</a></li>
                    <li><a href="https://www.youvisit.com/#/vte/?data-platform=v&data-inst=60105&data-image-width=100%&data-image-height=100%&" target="_blank">Virtual Tour</a></li>
                </ul>
            </div><!--end footer 2nd col-->
            <div class="col-md-2">
                <h5 class="text-uppercase">Public Safety</h5>
                <ul class="list-unstyled">
                    <li><a href="/emergency/">Emergency</a></li>
                    <li><a href="/police/">Police Department</a></li>
                    <li><a href="/offices/police/services/">Safety Cruiser</a></li>
                </ul>
            </div><!--end footer 3rd col-->
            <div class="col-md-2">
                <h5 class="text-uppercase">Campus Tools</h5>
                <ul class="list-unstyled">
                    <li><a href="https://mail.bradley.edu/">Bmail</a></li>
                    <li><a href="https://fsmail.bradley.edu/">FSmail</a></li>
                    <li><a href="https://learn.bradley.edu/">Canvas</a></li>
                    <li><a href="https://mybu.bradley.edu/">MyBU</a></li>
                    <li><a href="/directory/">Directory</a></li>
                </ul>
            </div><!--end footer 4th col-->
            <div class="col-md-4 contact-table">
                <div class="row row-padding-sm">
                    <div class="col-md-3 text-uppercase">Phone</div>
                    <div class="col-md-1"><i aria-hidden="true" class="fas fa-lg fa-phone"></i></div>
                    <div class="col-md-8"> (309) 676-7611 </div>
                </div>
                <div class="row row-padding-sm">
                    <div class="col-md-3 text-uppercase">Email</div>
                    <div class="col-md-1"><i aria-hidden="true" class="fas fa-lg fa-envelope"></i></div>
                    <div class="col-md-8"><a href="mailto:webmaster@bradley.edu">webmaster@bradley.edu</a></div>
                </div>
                <div class="row row-padding-sm">
                    <div class="col-md-3 text-uppercase">Location</div>
                    <div class="col-md-1"><i aria-hidden="true" class="fas fa-lg fa-map-marker-alt"></i></div>
                    <div class="col-md-8">1501 W Bradley Ave | Peoria, IL 61625</div>
                </div>
                <div class="row row-padding-sm">
                    <div class="col-md-3 text-uppercase">Connect</div>
                    <div class="col-md-1"><a href="https://www.facebook.com/BradleyUniversity" target="_blank"><i aria-hidden="true" class="fab fa-2x fa-facebook-f"></i><span class="sr-only">Facebook</span></a></div>
                    <div class="col-md-1"><a href="https://twitter.com/bradleyu" target="_blank"><i aria-hidden="true" class="fab fa-2x fa-twitter"></i><span class="sr-only">Twitter</span></a></div>
                    <div class="col-md-1"><a href="https://instagram.com/bradleyuniversity/" target="_blank"><i aria-hidden="true" class="fab fa-2x fa-instagram"></i><span class="sr-only">Instagram</span></a></div>
                    <div class="col-md-1"><a href="https://www.youtube.com/bradleyuniversity" target="_blank"><i aria-hidden="true" class="fab fa-2x fa-youtube"></i><span class="sr-only">Youtube</span></a></div>
                    <div class="col-md-1"><a href="https://www.linkedin.com/school/bradley-university/" target="_blank"><i aria-hidden="true" class="fab fa-2x fa-linkedin"></i><span class="sr-only">LinkedIn</span></a></div>
                </div>
                
                <div class="row row-padding-top-60">
                    <a href="/offices/business/human-resources/employment-opportunities/" class="btn btn-secondary-outline btn-lg btn-block btn-wrap-text">Careers at Bradley</a>
                </div>
            </div><!--end footer 5th col-->
        </div><!--end container for links-->
        <div class="container hidden-lg visible-xs-block visible-sm-block visible-md-block text-center">
            <div class="footer-logo">
                <p><img src="/asset/img/Blogo_white_Center.svg" alt="Bradley centered stacked logo"></p>
            </div>
            <p><i aria-hidden="true" class="fas fa-lg fa-phone"></i>  (309) 676-7611 </p>
            <p><i aria-hidden="true" class="fas fa-lg fa-envelope"></i> <a href="mailto:webmaster@bradley.edu">webmaster@bradley.edu</a></p>
            <p><i aria-hidden="true" class="fas fa-lg fa-map-marker-alt"></i> 1501 W Bradley Ave | Peoria, IL 61625</p>
            <div class="col-xs-12">
                <ul class="list-inline">
                    <li><a href="https://www.facebook.com/BradleyUniversity" target="_blank"><i aria-hidden="true" class="fab fa-2x fa-facebook-f"></i><span class="sr-only">Facebook</span></a></li>
                    <li><a href="https://twitter.com/bradleyu" target="_blank"><i aria-hidden="true" class="fab fa-2x fa-twitter"></i><span class="sr-only">Twitter</span></a></li>
                    <li><a href="https://instagram.com/bradleyuniversity/" target="_blank"><i aria-hidden="true" class="fab fa-2x fa-instagram"></i><span class="sr-only">Instagram</span></a></li>
                    <li><a href="https://www.youtube.com/bradleyuniversity" target="_blank"><i aria-hidden="true" class="fab fa-2x fa-youtube"></i><span class="sr-only">Youtube</span></a></li>
                    <li><a href="https://www.linkedin.com/school/bradley-university/" target="_blank"><i aria-hidden="true" class="fab fa-2x fa-linkedin"></i><span class="sr-only">LinkedIn</span></a></li>
                </ul>
            </div>
        </div><!--container hidden-md visible-xs-block visible-sm-block text-center-->
    </div><!--row row-color-charcoal-->
    <div class="row-color-charcoal copyright text-center row-padding-sm">
        <div class="container">
            <p><span aria-hidden="true" class="glyphicon glyphicon-copyright-mark"></span> 2025 Bradley University | <a href="/legal/accessibility/">Accessibility</a> | <a href="/legal/privacy/">Privacy Policy</a> | <a href="/legal/nondiscrimination/">Non-Discrimination Statement</a> | <a href="/legal/consumerinfo/">Consumer Information</a> | <a href="/legal/complaint-resolution/">Student Complaint Resolution</a> | <a href="https://complaints.ibhe.org/" target="_blank">IBHE Online Complaint System</a></p>
        </div>
    </div>
</footer>
<!-- end FOOTER -->

<script type="text/javascript">
_linkedin_partner_id = "5161916";
window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
window._linkedin_data_partner_ids.push(_linkedin_partner_id);
</script><script type="text/javascript">
(function(l) {
if (!l){window.lintrk = function(a,b){window.lintrk.q.push([a,b])};
window.lintrk.q=[]}
var s = document.getElementsByTagName("script")[0];
var b = document.createElement("script");
b.type = "text/javascript";b.async = true;
b.src = https://snap.licdn.com/li.lms-analytics/insight.min.js;
s.parentNode.insertBefore(b, s);})(window.lintrk);
</script>
<noscript>
<img height="1" width="1" style="display:none;" alt="" src=https://px.ads.linkedin.com/collect/?pid=5161916&fmt=gif />
</noscript>


<script> var apolloEventsConfig = { profile: "bradley" }; </script>
<script async src="https://apolloevents.rvaed.com/apolloevents.js"></script>
</body>
</html>